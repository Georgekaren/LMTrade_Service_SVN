package com.itheima.redbaby.vo;

/**
 * 发票
 * @author liu
 *
 */
public class Invoice {
	private int id;
	private String content;

	public Invoice() {
	}

	public Invoice(int id, String content) {
		super();
		this.id = id;
		this.content = content;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
