package com.itheima.redbaby.config;

public interface Constant {
	String pic_url = "http://192.168.120.33:8080/ECServer_D/images/";
	String RESPONSE = "response";
	String APK_URL = "http://192.168.1.23:8080/ECServer_D/redbaby.apk";
}
